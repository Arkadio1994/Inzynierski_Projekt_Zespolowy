-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 04 Maj 2017, 13:26
-- Wersja serwera: 5.5.55-0ubuntu0.14.04.1
-- Wersja PHP: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `apscrum`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `komentarzeproj`
--

CREATE TABLE IF NOT EXISTS `komentarzeproj` (
  `IDKomProj` int(11) NOT NULL AUTO_INCREMENT,
  `TrescKomProj` varchar(1000) DEFAULT NULL,
  `idprojektu` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDKomProj`),
  KEY `KPfkPRO` (`idprojektu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `komentarzezad`
--

CREATE TABLE IF NOT EXISTS `komentarzezad` (
  `IDKomZad` int(11) NOT NULL AUTO_INCREMENT,
  `TrescKomZad` text,
  `idzadanie` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDKomZad`),
  KEY `KZfkZAD` (`idzadanie`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownik`
--

CREATE TABLE IF NOT EXISTS `pracownik` (
  `IDPracownik` int(11) NOT NULL AUTO_INCREMENT,
  `idusera` int(11) DEFAULT NULL,
  `idroli` int(11) DEFAULT NULL,
  `idprojektu` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDPracownik`),
  KEY `PRfkUS` (`idusera`),
  KEY `PRfkRO` (`idroli`),
  KEY `PRfkPRO` (`idprojektu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Zrzut danych tabeli `pracownik`
--

INSERT INTO `pracownik` (`IDPracownik`, `idusera`, `idroli`, `idprojektu`) VALUES
(1, 1, 1, 1),
(2, 2, 3, 1),
(4, 3, 2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `projekt`
--

CREATE TABLE IF NOT EXISTS `projekt` (
  `IDProjektu` int(11) NOT NULL AUTO_INCREMENT,
  `Nazwa_projektu` varchar(15) NOT NULL,
  PRIMARY KEY (`IDProjektu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Zrzut danych tabeli `projekt`
--

INSERT INTO `projekt` (`IDProjektu`, `Nazwa_projektu`) VALUES
(1, 'projekt 1'),
(2, 'projekt_Test'),
(10, 'projekt66876');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rola`
--

CREATE TABLE IF NOT EXISTS `rola` (
  `IDRola` int(11) NOT NULL AUTO_INCREMENT,
  `Nazwa_roli` varchar(50) NOT NULL,
  PRIMARY KEY (`IDRola`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Zrzut danych tabeli `rola`
--

INSERT INTO `rola` (`IDRola`, `Nazwa_roli`) VALUES
(1, 'Programista'),
(2, 'bazodanowiec'),
(3, 'grafik');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `sprint`
--

CREATE TABLE IF NOT EXISTS `sprint` (
  `IDSprint` int(11) NOT NULL AUTO_INCREMENT,
  `Nazwa_sprintu` varchar(50) DEFAULT NULL,
  `Opis_sprintu` text,
  `CzasTrwaniaSprintu` int(11) DEFAULT NULL,
  `data_start` date DEFAULT NULL,
  `data_koniec` date DEFAULT NULL,
  `idprojekt` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDSprint`),
  KEY `SPRfkPRO` (`idprojekt`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Zrzut danych tabeli `sprint`
--

INSERT INTO `sprint` (`IDSprint`, `Nazwa_sprintu`, `Opis_sprintu`, `CzasTrwaniaSprintu`, `data_start`, `data_koniec`, `idprojekt`) VALUES
(1, 'sprint1', 'xfhghgfcb\r\nfgxcbg\r\nfgx', 16, '2017-05-04', '2017-05-04', 1),
(2, 'spint2', 'test test test test test test test test test test test test', 1, '2017-05-04', '2017-05-04', 1),
(3, 'testtest', 'qwertyrtrefbfhdfb', 7, NULL, '0000-00-00', NULL),
(4, '4r4e', 'redt', 1, NULL, '0000-00-00', NULL),
(5, '4r4e', 'redt', 1, NULL, '0000-00-00', NULL),
(6, 'test', 'vdcjadsbv', 5, '2017-05-04', '2017-05-04', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stan`
--

CREATE TABLE IF NOT EXISTS `stan` (
  `IDStan` int(11) NOT NULL AUTO_INCREMENT,
  `Nazwa_stanu` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`IDStan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Zrzut danych tabeli `stan`
--

INSERT INTO `stan` (`IDStan`, `Nazwa_stanu`) VALUES
(1, 'do zrobienia');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `IDUser` int(11) NOT NULL AUTO_INCREMENT,
  `Login` varchar(50) DEFAULT NULL,
  `Haslo` varchar(20) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Imie` varchar(30) DEFAULT NULL,
  `Nazwisko` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`IDUser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Zrzut danych tabeli `user`
--

INSERT INTO `user` (`IDUser`, `Login`, `Haslo`, `Email`, `Imie`, `Nazwisko`) VALUES
(1, 'admin', 'admin', 'qqwqwqw@gmail.com', 'qwe', 'qweqe'),
(2, 'admin', 'admin', 'qqwqwqw@gmail.com', 'qwe', 'qweqe'),
(3, NULL, NULL, NULL, 'vhk', 'cfn'),
(4, NULL, NULL, NULL, 'sdcsdc', 'dwew');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zadania`
--

CREATE TABLE IF NOT EXISTS `zadania` (
  `IDZadania` int(11) NOT NULL AUTO_INCREMENT,
  `Nazwa_zadania` varchar(50) DEFAULT NULL,
  `CzasTrwaniaZad` int(11) DEFAULT NULL,
  `OpisZadania` text,
  `idprojektu` int(11) DEFAULT NULL,
  `idstanu` int(11) DEFAULT NULL,
  `idsprintu` int(11) DEFAULT NULL,
  `idpracownika` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDZadania`),
  KEY `ZADfkPRO` (`idprojektu`),
  KEY `ZADfkST` (`idstanu`),
  KEY `ZADfkSPR` (`idsprintu`),
  KEY `ZADfkPRA` (`idpracownika`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Zrzut danych tabeli `zadania`
--

INSERT INTO `zadania` (`IDZadania`, `Nazwa_zadania`, `CzasTrwaniaZad`, `OpisZadania`, `idprojektu`, `idstanu`, `idsprintu`, `idpracownika`) VALUES
(1, 'zadanie1', 3, 'qwertyuigmh qr342trg', 1, 1, 1, 1),
(2, 'zadanie2', 5, 'qweddvsg arg eg\r\ngylhik', 1, 1, 1, 1),
(5, 'zadanie3', 7, 'yut', 2, 1, 1, 1),
(7, 'zadanie78', 6, 'yujyjtfyh', 1, 1, NULL, 1),
(8, 'test1863', 4, 'klvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvddddklvmdmdfvdddd', 1, 1, 2, 4);

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `komentarzeproj`
--
ALTER TABLE `komentarzeproj`
  ADD CONSTRAINT `KPfkPRO` FOREIGN KEY (`idprojektu`) REFERENCES `projekt` (`IDProjektu`);

--
-- Ograniczenia dla tabeli `komentarzezad`
--
ALTER TABLE `komentarzezad`
  ADD CONSTRAINT `KZfkZAD` FOREIGN KEY (`idzadanie`) REFERENCES `zadania` (`IDZadania`);

--
-- Ograniczenia dla tabeli `pracownik`
--
ALTER TABLE `pracownik`
  ADD CONSTRAINT `PRfkPRO` FOREIGN KEY (`idprojektu`) REFERENCES `projekt` (`IDProjektu`),
  ADD CONSTRAINT `PRfkRO` FOREIGN KEY (`idroli`) REFERENCES `rola` (`IDRola`),
  ADD CONSTRAINT `PRfkUS` FOREIGN KEY (`idusera`) REFERENCES `user` (`IDUser`);

--
-- Ograniczenia dla tabeli `sprint`
--
ALTER TABLE `sprint`
  ADD CONSTRAINT `SPRfkPRO` FOREIGN KEY (`idprojekt`) REFERENCES `projekt` (`IDProjektu`);

--
-- Ograniczenia dla tabeli `zadania`
--
ALTER TABLE `zadania`
  ADD CONSTRAINT `ZADfkPRA` FOREIGN KEY (`idpracownika`) REFERENCES `pracownik` (`IDPracownik`),
  ADD CONSTRAINT `ZADfkPRO` FOREIGN KEY (`idprojektu`) REFERENCES `projekt` (`IDProjektu`),
  ADD CONSTRAINT `ZADfkSPR` FOREIGN KEY (`idsprintu`) REFERENCES `sprint` (`IDSprint`),
  ADD CONSTRAINT `ZADfkST` FOREIGN KEY (`idstanu`) REFERENCES `stan` (`IDStan`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
